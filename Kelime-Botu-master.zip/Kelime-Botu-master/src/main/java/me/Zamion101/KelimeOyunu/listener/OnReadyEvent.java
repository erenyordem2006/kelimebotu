package me.Zamion101.KelimeOyunu.listener;

import sx.blah.discord.api.events.IListener;
import sx.blah.discord.handle.impl.events.ReadyEvent;

public class OnReadyEvent implements IListener<ReadyEvent> {

    @Override
    public void handle(ReadyEvent readyEvent) {
    }
}
